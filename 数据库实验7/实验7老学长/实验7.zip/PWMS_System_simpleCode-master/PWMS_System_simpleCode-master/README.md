# PWMS_System_simpleCode
人事管理系统

基于VS 2010构建，版本要求： vs 2010以上
