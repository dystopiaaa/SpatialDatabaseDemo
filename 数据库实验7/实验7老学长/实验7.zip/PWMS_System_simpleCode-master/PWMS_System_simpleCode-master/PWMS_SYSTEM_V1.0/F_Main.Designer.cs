﻿namespace PWMS_SYSTEM_V1._0
{
    partial class F_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Button_Stuffbusic = new System.Windows.Forms.ToolStripButton();
            this.Button_Stufind = new System.Windows.Forms.ToolStripButton();
            this.Button_ClewBargain = new System.Windows.Forms.ToolStripButton();
            this.Botton_AddressBook = new System.Windows.Forms.ToolStripButton();
            this.Botton_DayWordPad = new System.Windows.Forms.ToolStripButton();
            this.Button_Close = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Menu_1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Folk = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_EmployeeGenre = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Kultur = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Visage = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Branch = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Laborage = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Business = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Duthcall = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_RPKind = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_WordPad = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_3 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_ClewBirthday = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_ClewBargain = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_4 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stuffbusic = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stufind = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stusum = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_5 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_DayWordPad = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_AddressBook = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_6 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Back = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Clear = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_7 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Counter = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_WordBook = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_8 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_NewLogon = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Setup = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_9 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_11 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Button_Stuffbusic,
            this.Button_Stufind,
            this.Button_ClewBargain,
            this.Botton_AddressBook,
            this.Botton_DayWordPad,
            this.Button_Close});
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(785, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Button_Stuffbusic
            // 
            this.Button_Stuffbusic.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._01;
            this.Button_Stuffbusic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Stuffbusic.Name = "Button_Stuffbusic";
            this.Button_Stuffbusic.Size = new System.Drawing.Size(100, 22);
            this.Button_Stuffbusic.Text = "人事档案浏览";
            this.Button_Stuffbusic.Click += new System.EventHandler(this.Button_Stuffbusic_Click);
            // 
            // Button_Stufind
            // 
            this.Button_Stufind.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._02;
            this.Button_Stufind.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Stufind.Name = "Button_Stufind";
            this.Button_Stufind.Size = new System.Drawing.Size(100, 22);
            this.Button_Stufind.Text = "人事资料查询";
            this.Button_Stufind.Click += new System.EventHandler(this.Button_Stufind_Click);
            // 
            // Button_ClewBargain
            // 
            this.Button_ClewBargain.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._03;
            this.Button_ClewBargain.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_ClewBargain.Name = "Button_ClewBargain";
            this.Button_ClewBargain.Size = new System.Drawing.Size(100, 22);
            this.Button_ClewBargain.Text = "员工合同提示";
            this.Button_ClewBargain.Click += new System.EventHandler(this.Button_ClewBargain_Click);
            // 
            // Botton_AddressBook
            // 
            this.Botton_AddressBook.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._04;
            this.Botton_AddressBook.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botton_AddressBook.Name = "Botton_AddressBook";
            this.Botton_AddressBook.Size = new System.Drawing.Size(64, 22);
            this.Botton_AddressBook.Text = "通讯录";
            this.Botton_AddressBook.Click += new System.EventHandler(this.Botton_AddressBook_Click);
            // 
            // Botton_DayWordPad
            // 
            this.Botton_DayWordPad.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._05;
            this.Botton_DayWordPad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botton_DayWordPad.Name = "Botton_DayWordPad";
            this.Botton_DayWordPad.Size = new System.Drawing.Size(76, 22);
            this.Botton_DayWordPad.Text = "日常记事";
            this.Botton_DayWordPad.Click += new System.EventHandler(this.Botton_DayWordPad_Click);
            // 
            // Button_Close
            // 
            this.Button_Close.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources._06;
            this.Button_Close.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Close.Name = "Button_Close";
            this.Button_Close.Size = new System.Drawing.Size(76, 22);
            this.Button_Close.Text = "退出系统";
            this.Button_Close.Click += new System.EventHandler(this.Button_Close_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 493);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(785, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(164, 17);
            this.toolStripStatusLabel1.Text = "||欢迎使用企业人事管理系统||";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(128, 17);
            this.toolStripStatusLabel2.Text = "　当前登录用户：　　";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(0, 17);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_1,
            this.Menu_4,
            this.Menu_5,
            this.Menu_6,
            this.Menu_7,
            this.Menu_8,
            this.Menu_10});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(785, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Menu_1
            // 
            this.Menu_1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_2,
            this.Menu_3});
            this.Menu_1.Name = "Menu_1";
            this.Menu_1.Size = new System.Drawing.Size(92, 21);
            this.Menu_1.Text = "基础信息管理";
            // 
            // Menu_2
            // 
            this.Menu_2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Folk,
            this.Tool_EmployeeGenre,
            this.Tool_Kultur,
            this.Tool_Visage,
            this.Tool_Branch,
            this.Tool_Laborage,
            this.Tool_Business,
            this.Tool_Duthcall,
            this.Tool_RPKind,
            this.Tool_WordPad});
            this.Menu_2.Name = "Menu_2";
            this.Menu_2.Size = new System.Drawing.Size(148, 22);
            this.Menu_2.Text = "数据基础";
            // 
            // Tool_Folk
            // 
            this.Tool_Folk.Name = "Tool_Folk";
            this.Tool_Folk.Size = new System.Drawing.Size(160, 22);
            this.Tool_Folk.Text = "民族类别设置";
            this.Tool_Folk.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_EmployeeGenre
            // 
            this.Tool_EmployeeGenre.Name = "Tool_EmployeeGenre";
            this.Tool_EmployeeGenre.Size = new System.Drawing.Size(160, 22);
            this.Tool_EmployeeGenre.Text = "职工类别设置";
            this.Tool_EmployeeGenre.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Kultur
            // 
            this.Tool_Kultur.Name = "Tool_Kultur";
            this.Tool_Kultur.Size = new System.Drawing.Size(160, 22);
            this.Tool_Kultur.Text = "文化程度设置";
            this.Tool_Kultur.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Visage
            // 
            this.Tool_Visage.Name = "Tool_Visage";
            this.Tool_Visage.Size = new System.Drawing.Size(160, 22);
            this.Tool_Visage.Text = "政治面貌设置";
            this.Tool_Visage.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Branch
            // 
            this.Tool_Branch.Name = "Tool_Branch";
            this.Tool_Branch.Size = new System.Drawing.Size(160, 22);
            this.Tool_Branch.Text = "部门类别设置";
            this.Tool_Branch.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Laborage
            // 
            this.Tool_Laborage.Name = "Tool_Laborage";
            this.Tool_Laborage.Size = new System.Drawing.Size(160, 22);
            this.Tool_Laborage.Text = "工资类别设置";
            this.Tool_Laborage.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Business
            // 
            this.Tool_Business.Name = "Tool_Business";
            this.Tool_Business.Size = new System.Drawing.Size(160, 22);
            this.Tool_Business.Text = "职务类别设置";
            this.Tool_Business.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Duthcall
            // 
            this.Tool_Duthcall.Name = "Tool_Duthcall";
            this.Tool_Duthcall.Size = new System.Drawing.Size(160, 22);
            this.Tool_Duthcall.Text = "职称类别设置";
            this.Tool_Duthcall.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_RPKind
            // 
            this.Tool_RPKind.Name = "Tool_RPKind";
            this.Tool_RPKind.Size = new System.Drawing.Size(160, 22);
            this.Tool_RPKind.Text = "奖惩类别设置";
            this.Tool_RPKind.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_WordPad
            // 
            this.Tool_WordPad.Name = "Tool_WordPad";
            this.Tool_WordPad.Size = new System.Drawing.Size(160, 22);
            this.Tool_WordPad.Text = "记事本类别设置";
            this.Tool_WordPad.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Menu_3
            // 
            this.Menu_3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_ClewBirthday,
            this.Tool_ClewBargain});
            this.Menu_3.Name = "Menu_3";
            this.Menu_3.Size = new System.Drawing.Size(148, 22);
            this.Menu_3.Text = "员工提示信息";
            // 
            // Tool_ClewBirthday
            // 
            this.Tool_ClewBirthday.Name = "Tool_ClewBirthday";
            this.Tool_ClewBirthday.Size = new System.Drawing.Size(148, 22);
            this.Tool_ClewBirthday.Tag = "1";
            this.Tool_ClewBirthday.Text = "员工生日提示";
            this.Tool_ClewBirthday.Click += new System.EventHandler(this.Tool_ClewBirthday_Click);
            // 
            // Tool_ClewBargain
            // 
            this.Tool_ClewBargain.Name = "Tool_ClewBargain";
            this.Tool_ClewBargain.Size = new System.Drawing.Size(148, 22);
            this.Tool_ClewBargain.Tag = "2";
            this.Tool_ClewBargain.Text = "员工合同提示";
            this.Tool_ClewBargain.Click += new System.EventHandler(this.Tool_ClewBargain_Click);
            // 
            // Menu_4
            // 
            this.Menu_4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Stuffbusic,
            this.Tool_Stufind,
            this.Tool_Stusum});
            this.Menu_4.Name = "Menu_4";
            this.Menu_4.Size = new System.Drawing.Size(68, 21);
            this.Menu_4.Text = "人事管理";
            // 
            // Tool_Stuffbusic
            // 
            this.Tool_Stuffbusic.Name = "Tool_Stuffbusic";
            this.Tool_Stuffbusic.Size = new System.Drawing.Size(148, 22);
            this.Tool_Stuffbusic.Text = "人事档案浏览";
            this.Tool_Stuffbusic.Click += new System.EventHandler(this.Tool_Stuffbusic_Click);
            // 
            // Tool_Stufind
            // 
            this.Tool_Stufind.Name = "Tool_Stufind";
            this.Tool_Stufind.Size = new System.Drawing.Size(148, 22);
            this.Tool_Stufind.Text = "人事资料查询";
            this.Tool_Stufind.Click += new System.EventHandler(this.Tool_Stufind_Click);
            // 
            // Tool_Stusum
            // 
            this.Tool_Stusum.Name = "Tool_Stusum";
            this.Tool_Stusum.Size = new System.Drawing.Size(148, 22);
            this.Tool_Stusum.Text = "人事资料统计";
            this.Tool_Stusum.Click += new System.EventHandler(this.Tool_Stusum_Click);
            // 
            // Menu_5
            // 
            this.Menu_5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_DayWordPad,
            this.Tool_AddressBook});
            this.Menu_5.Name = "Menu_5";
            this.Menu_5.Size = new System.Drawing.Size(68, 21);
            this.Menu_5.Text = "备忘记录";
            // 
            // Tool_DayWordPad
            // 
            this.Tool_DayWordPad.Name = "Tool_DayWordPad";
            this.Tool_DayWordPad.Size = new System.Drawing.Size(124, 22);
            this.Tool_DayWordPad.Text = "日常记事";
            this.Tool_DayWordPad.Click += new System.EventHandler(this.Tool_DayWordPad_Click);
            // 
            // Tool_AddressBook
            // 
            this.Tool_AddressBook.Name = "Tool_AddressBook";
            this.Tool_AddressBook.Size = new System.Drawing.Size(124, 22);
            this.Tool_AddressBook.Text = "通讯录";
            this.Tool_AddressBook.Click += new System.EventHandler(this.Tool_AddressBook_Click);
            // 
            // Menu_6
            // 
            this.Menu_6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Back,
            this.Tool_Clear});
            this.Menu_6.Name = "Menu_6";
            this.Menu_6.Size = new System.Drawing.Size(56, 21);
            this.Menu_6.Text = "数据库";
            // 
            // Tool_Back
            // 
            this.Tool_Back.Name = "Tool_Back";
            this.Tool_Back.Size = new System.Drawing.Size(165, 22);
            this.Tool_Back.Text = "备份/还原数据库";
            this.Tool_Back.Click += new System.EventHandler(this.Tool_Back_Click);
            // 
            // Tool_Clear
            // 
            this.Tool_Clear.Name = "Tool_Clear";
            this.Tool_Clear.Size = new System.Drawing.Size(165, 22);
            this.Tool_Clear.Text = "清空数据库";
            this.Tool_Clear.Click += new System.EventHandler(this.Tool_Clear_Click);
            // 
            // Menu_7
            // 
            this.Menu_7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Counter,
            this.Tool_WordBook});
            this.Menu_7.Name = "Menu_7";
            this.Menu_7.Size = new System.Drawing.Size(68, 21);
            this.Menu_7.Text = "工具管理";
            // 
            // Tool_Counter
            // 
            this.Tool_Counter.Name = "Tool_Counter";
            this.Tool_Counter.Size = new System.Drawing.Size(112, 22);
            this.Tool_Counter.Text = "计算器";
            this.Tool_Counter.Click += new System.EventHandler(this.Tool_Counter_Click);
            // 
            // Tool_WordBook
            // 
            this.Tool_WordBook.Name = "Tool_WordBook";
            this.Tool_WordBook.Size = new System.Drawing.Size(112, 22);
            this.Tool_WordBook.Text = "记事本";
            // 
            // Menu_8
            // 
            this.Menu_8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_NewLogon,
            this.Tool_Setup,
            this.Menu_9});
            this.Menu_8.Name = "Menu_8";
            this.Menu_8.Size = new System.Drawing.Size(68, 21);
            this.Menu_8.Text = "系统管理";
            // 
            // Tool_NewLogon
            // 
            this.Tool_NewLogon.Name = "Tool_NewLogon";
            this.Tool_NewLogon.Size = new System.Drawing.Size(124, 22);
            this.Tool_NewLogon.Text = "重新登录";
            this.Tool_NewLogon.Click += new System.EventHandler(this.Tool_NewLogon_Click);
            // 
            // Tool_Setup
            // 
            this.Tool_Setup.Name = "Tool_Setup";
            this.Tool_Setup.Size = new System.Drawing.Size(124, 22);
            this.Tool_Setup.Text = "用户设置";
            this.Tool_Setup.Click += new System.EventHandler(this.Tool_Setup_Click);
            // 
            // Menu_9
            // 
            this.Menu_9.Name = "Menu_9";
            this.Menu_9.Size = new System.Drawing.Size(124, 22);
            this.Menu_9.Text = "系统退出";
            // 
            // Menu_10
            // 
            this.Menu_10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_11});
            this.Menu_10.Name = "Menu_10";
            this.Menu_10.Size = new System.Drawing.Size(44, 21);
            this.Menu_10.Text = "帮助";
            // 
            // Menu_11
            // 
            this.Menu_11.Name = "Menu_11";
            this.Menu_11.Size = new System.Drawing.Size(100, 22);
            this.Menu_11.Text = "帮助";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 50);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox1);
            this.splitContainer1.Size = new System.Drawing.Size(785, 443);
            this.splitContainer1.SplitterDistance = 166;
            this.splitContainer1.TabIndex = 6;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(166, 443);
            this.treeView1.TabIndex = 0;
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::PWMS_SYSTEM_V1._0.Properties.Resources.主界面;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(615, 443);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // F_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(785, 515);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "F_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "F_Main";
            this.Activated += new System.EventHandler(this.F_Main_Activated);
            this.Load += new System.EventHandler(this.F_Main_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton Button_Stuffbusic;
        private System.Windows.Forms.ToolStripButton Button_Stufind;
        private System.Windows.Forms.ToolStripButton Button_ClewBargain;
        private System.Windows.Forms.ToolStripButton Botton_AddressBook;
        private System.Windows.Forms.ToolStripButton Botton_DayWordPad;
        private System.Windows.Forms.ToolStripButton Button_Close;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Menu_1;
        private System.Windows.Forms.ToolStripMenuItem Menu_2;
        private System.Windows.Forms.ToolStripMenuItem Tool_Folk;
        private System.Windows.Forms.ToolStripMenuItem Tool_EmployeeGenre;
        private System.Windows.Forms.ToolStripMenuItem Tool_Kultur;
        private System.Windows.Forms.ToolStripMenuItem Tool_Visage;
        private System.Windows.Forms.ToolStripMenuItem Tool_Branch;
        private System.Windows.Forms.ToolStripMenuItem Tool_Laborage;
        private System.Windows.Forms.ToolStripMenuItem Tool_Business;
        private System.Windows.Forms.ToolStripMenuItem Tool_Duthcall;
        private System.Windows.Forms.ToolStripMenuItem Tool_RPKind;
        private System.Windows.Forms.ToolStripMenuItem Tool_WordPad;
        private System.Windows.Forms.ToolStripMenuItem Menu_3;
        private System.Windows.Forms.ToolStripMenuItem Tool_ClewBirthday;
        private System.Windows.Forms.ToolStripMenuItem Tool_ClewBargain;
        private System.Windows.Forms.ToolStripMenuItem Menu_4;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stuffbusic;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stufind;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stusum;
        private System.Windows.Forms.ToolStripMenuItem Menu_5;
        private System.Windows.Forms.ToolStripMenuItem Tool_DayWordPad;
        private System.Windows.Forms.ToolStripMenuItem Tool_AddressBook;
        private System.Windows.Forms.ToolStripMenuItem Menu_6;
        private System.Windows.Forms.ToolStripMenuItem Tool_Back;
        private System.Windows.Forms.ToolStripMenuItem Tool_Clear;
        private System.Windows.Forms.ToolStripMenuItem Menu_7;
        private System.Windows.Forms.ToolStripMenuItem Tool_Counter;
        private System.Windows.Forms.ToolStripMenuItem Tool_WordBook;
        private System.Windows.Forms.ToolStripMenuItem Menu_8;
        private System.Windows.Forms.ToolStripMenuItem Tool_NewLogon;
        private System.Windows.Forms.ToolStripMenuItem Tool_Setup;
        private System.Windows.Forms.ToolStripMenuItem Menu_9;
        private System.Windows.Forms.ToolStripMenuItem Menu_10;
        private System.Windows.Forms.ToolStripMenuItem Menu_11;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
    }
}