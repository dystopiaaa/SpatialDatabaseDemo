﻿namespace PWMS_SYSTEM_V1._0.Perform
{
    partial class F_WordPad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Word_Save = new System.Windows.Forms.Button();
            this.Word_Cancel = new System.Windows.Forms.Button();
            this.Word_Delete = new System.Windows.Forms.Button();
            this.Word_Amend = new System.Windows.Forms.Button();
            this.Word_Add = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.WordPad_4 = new System.Windows.Forms.TextBox();
            this.WordPad_3 = new System.Windows.Forms.TextBox();
            this.WordPad_2 = new System.Windows.Forms.ComboBox();
            this.WordPad_1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 56);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查询";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(432, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(300, 20);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(105, 20);
            this.comboBox1.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(95, 20);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(114, 21);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.Value = new System.DateTime(2007, 11, 9, 0, 0, 0, 0);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(226, 23);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "记事类别";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(23, 25);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "记事时间";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "主    题：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Word_Save);
            this.groupBox4.Controls.Add(this.Word_Cancel);
            this.groupBox4.Controls.Add(this.Word_Delete);
            this.groupBox4.Controls.Add(this.Word_Amend);
            this.groupBox4.Controls.Add(this.Word_Add);
            this.groupBox4.Location = new System.Drawing.Point(218, 348);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(335, 50);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // Word_Save
            // 
            this.Word_Save.Location = new System.Drawing.Point(260, 18);
            this.Word_Save.Name = "Word_Save";
            this.Word_Save.Size = new System.Drawing.Size(53, 23);
            this.Word_Save.TabIndex = 4;
            this.Word_Save.Text = "保存";
            this.Word_Save.UseVisualStyleBackColor = true;
            this.Word_Save.Click += new System.EventHandler(this.Word_Save_Click);
            // 
            // Word_Cancel
            // 
            this.Word_Cancel.Location = new System.Drawing.Point(201, 18);
            this.Word_Cancel.Name = "Word_Cancel";
            this.Word_Cancel.Size = new System.Drawing.Size(53, 23);
            this.Word_Cancel.TabIndex = 3;
            this.Word_Cancel.Text = "取消";
            this.Word_Cancel.UseVisualStyleBackColor = true;
            this.Word_Cancel.Click += new System.EventHandler(this.Word_Cancel_Click);
            // 
            // Word_Delete
            // 
            this.Word_Delete.Location = new System.Drawing.Point(142, 18);
            this.Word_Delete.Name = "Word_Delete";
            this.Word_Delete.Size = new System.Drawing.Size(53, 23);
            this.Word_Delete.TabIndex = 2;
            this.Word_Delete.Text = "删除";
            this.Word_Delete.UseVisualStyleBackColor = true;
            this.Word_Delete.Click += new System.EventHandler(this.Word_Delete_Click);
            // 
            // Word_Amend
            // 
            this.Word_Amend.Location = new System.Drawing.Point(83, 18);
            this.Word_Amend.Name = "Word_Amend";
            this.Word_Amend.Size = new System.Drawing.Size(53, 23);
            this.Word_Amend.TabIndex = 1;
            this.Word_Amend.Text = "修改";
            this.Word_Amend.UseVisualStyleBackColor = true;
            this.Word_Amend.Click += new System.EventHandler(this.button3_Click);
            // 
            // Word_Add
            // 
            this.Word_Add.Location = new System.Drawing.Point(24, 18);
            this.Word_Add.Name = "Word_Add";
            this.Word_Add.Size = new System.Drawing.Size(53, 23);
            this.Word_Add.TabIndex = 0;
            this.Word_Add.Text = "添加";
            this.Word_Add.UseVisualStyleBackColor = true;
            this.Word_Add.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "内容：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.WordPad_4);
            this.groupBox3.Controls.Add(this.WordPad_3);
            this.groupBox3.Controls.Add(this.WordPad_2);
            this.groupBox3.Controls.Add(this.WordPad_1);
            this.groupBox3.Location = new System.Drawing.Point(218, 79);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(335, 267);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "记事本内容";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "记事类别：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "记事时间：";
            // 
            // WordPad_4
            // 
            this.WordPad_4.Location = new System.Drawing.Point(11, 123);
            this.WordPad_4.Multiline = true;
            this.WordPad_4.Name = "WordPad_4";
            this.WordPad_4.Size = new System.Drawing.Size(314, 132);
            this.WordPad_4.TabIndex = 3;
            // 
            // WordPad_3
            // 
            this.WordPad_3.Location = new System.Drawing.Point(77, 76);
            this.WordPad_3.Name = "WordPad_3";
            this.WordPad_3.Size = new System.Drawing.Size(248, 21);
            this.WordPad_3.TabIndex = 2;
            // 
            // WordPad_2
            // 
            this.WordPad_2.FormattingEnabled = true;
            this.WordPad_2.Location = new System.Drawing.Point(77, 49);
            this.WordPad_2.Name = "WordPad_2";
            this.WordPad_2.Size = new System.Drawing.Size(113, 20);
            this.WordPad_2.TabIndex = 1;
            // 
            // WordPad_1
            // 
            this.WordPad_1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.WordPad_1.Location = new System.Drawing.Point(77, 22);
            this.WordPad_1.Name = "WordPad_1";
            this.WordPad_1.Size = new System.Drawing.Size(113, 21);
            this.WordPad_1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(180, 267);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEnter);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(10, 296);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(72, 16);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "全部显示";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.Click += new System.EventHandler(this.checkBox3_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(12, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 319);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "信息表";
            // 
            // F_WordPad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 410);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "F_WordPad";
            this.Text = "F_WordPad";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.Load += new System.EventHandler(this.F_WordPad_Load);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button Word_Save;
        private System.Windows.Forms.Button Word_Cancel;
        private System.Windows.Forms.Button Word_Delete;
        private System.Windows.Forms.Button Word_Amend;
        private System.Windows.Forms.Button Word_Add;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox WordPad_4;
        private System.Windows.Forms.TextBox WordPad_3;
        private System.Windows.Forms.ComboBox WordPad_2;
        private System.Windows.Forms.DateTimePicker WordPad_1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}